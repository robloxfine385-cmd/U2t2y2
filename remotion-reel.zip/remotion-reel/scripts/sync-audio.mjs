// Reads public/voiceover.mp3 (or .wav/.m4a/.aac), measures its length, speech start/end and pauses,
// and writes src/timing.json. Runs automatically before `studio`, `render` and `still`.
// Never fails the pipeline: with no audio file the project renders silently with estimated timing.
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

const TIMING = "src/timing.json";
const CANDIDATES = ["voiceover.mp3", "voiceover.wav", "voiceover.m4a", "voiceover.aac"];

const timing = JSON.parse(readFileSync(TIMING, "utf8"));
const save = () => writeFileSync(TIMING, JSON.stringify(timing, null, 2) + "\n");

const file = CANDIDATES.find((f) => existsSync(`public/${f}`));
if (!file) {
  timing.hasAudio = false;
  timing.audioFile = null;
  save();
  console.log("[sync-audio] public/voiceover.mp3 not found → no voiceover, estimated timing.");
  process.exit(0);
}

// Enable audio right away so it plays even if the analysis below cannot run.
timing.audioFile = file;
timing.hasAudio = true;

const has = (cmd) => spawnSync(cmd, ["-version"], { stdio: "ignore" }).status === 0;
const ff = has("ffmpeg") ? ["ffmpeg"] : ["npx", "remotion", "ffmpeg"];
const r = spawnSync(
  ff[0],
  [...ff.slice(1), "-v", "error", "-i", `public/${file}`, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "pipe:1"],
  { maxBuffer: 1 << 29 },
);
if (r.status !== 0 || !r.stdout || r.stdout.length < 32000) {
  save();
  console.warn(`[sync-audio] could not analyse ${file}; audio will play, timing stays estimated.`);
  process.exit(0);
}

const SR = 16000;
const WIN = 800; // 50 ms
const pcm = r.stdout;
const n = Math.floor(pcm.length / 2);
const db = [];
for (let i = 0; i + WIN <= n; i += WIN) {
  let sum = 0;
  for (let j = 0; j < WIN; j++) {
    const v = pcm.readInt16LE((i + j) * 2) / 32768;
    sum += v * v;
  }
  db.push(10 * Math.log10(sum / WIN + 1e-12));
}
const STEP = WIN / SR;
const duration = n / SR;

const sorted = [...db].sort((a, b) => a - b);
const thr = sorted[Math.floor(sorted.length * 0.7)] - 15;
const loud = db.map((v) => v > thr);

let first = loud.findIndex((v, i) => v && loud[i + 1] && loud[i + 2]);
let last = -1;
for (let i = loud.length - 1; i >= 2; i--) {
  if (loud[i] && loud[i - 1] && loud[i - 2]) {
    last = i;
    break;
  }
}
if (first < 0 || last <= first) {
  first = 0;
  last = loud.length - 1;
}

const pauses = [];
let run = -1;
for (let i = first; i <= last; i++) {
  if (!loud[i]) {
    if (run < 0) run = i;
  } else if (run >= 0) {
    const len = i - run;
    if (len >= 4) pauses.push({ t: +(((run + i) / 2) * STEP).toFixed(2), d: +(len * STEP).toFixed(2) });
    run = -1;
  }
}

timing.duration = +duration.toFixed(2);
timing.speechStart = +Math.max(0, first * STEP - 0.05).toFixed(2);
timing.speechEnd = +Math.min(duration, (last + 1) * STEP).toFixed(2);
timing.pauses = pauses;
save();
console.log(
  `[sync-audio] ${file}: ${timing.duration}s, speech ${timing.speechStart}s → ${timing.speechEnd}s, ${pauses.length} pauses`,
);
