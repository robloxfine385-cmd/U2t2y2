import { alignSentences, splitPhrases, timePhrases } from "./autoSync";
import type { Pause, Seg } from "./autoSync";
import { BEAT_DEFS, SCRIPT } from "./script";
import type { Beat } from "./script";
import timing from "./timing.json";

const PAUSES = timing.pauses as Pause[];

/** One entry per script sentence, aligned to the audio. */
export const SENTENCES: Seg[] = alignSentences(SCRIPT, {
  start: timing.speechStart,
  end: timing.speechEnd,
  pauses: PAUSES,
});

/** Short caption parts (≤ 4 words), each with its own start/end. */
export const PHRASES: Seg[] = SENTENCES.flatMap((s) =>
  timePhrases(splitPhrases(s.text), s.start, s.end, PAUSES),
);

/** Beat definitions resolved to absolute seconds. */
export const BEATS: Beat[] = BEAT_DEFS.map((def) => {
  const first = SENTENCES[def.from];
  const last = SENTENCES[def.to ?? def.from];
  const span = last.end - first.start;
  const start = first.start + span * (def.a ?? 0) + 0.08;
  const end = Math.max(start + 0.6, first.start + span * (def.b ?? 1) - 0.05);
  return { ...def, start, end } as unknown as Beat;
});
