import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { FPS, L } from "../config";
import { PHRASES } from "../timing";
import { theme } from "../theme";
import { Glass } from "./Motion";

type Word = { text: string; s: number; e: number };
type Page = { s: number; e: number; words: Word[] };

// Each short caption part is one "page"; word highlight timing is proportional to word length (frames).
const PAGES: Page[] = PHRASES.map((p) => {
  const words = p.text.split(/\s+/).filter(Boolean);
  const w = words.map((x) => [...x].length + 1);
  const total = w.reduce((a, b) => a + b, 0);
  const s0 = p.start * FPS;
  const dur = (p.end - p.start) * FPS;
  let acc = 0;
  const timed: Word[] = words.map((text, i) => {
    const s = s0 + (dur * acc) / total;
    acc += w[i];
    return { text, s, e: s0 + (dur * acc) / total };
  });
  return { s: s0, e: s0 + dur, words: timed };
});

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  let page: Page | null = null;
  for (let i = PAGES.length - 1; i >= 0; i--) {
    if (frame >= PAGES[i].s && frame < PAGES[i].e + 4) {
      page = PAGES[i];
      break;
    }
  }
  if (!page) return null;

  const enter = spring({ frame: frame - page.s, fps, config: theme.spring.snappy });

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <div
        style={{
          position: "absolute",
          left: 40,
          right: 40,
          top: L.captionY,
          display: "flex",
          justifyContent: "center",
          opacity: Math.min(1, enter * 1.6),
          transform: `translateY(-50%) translateY(${interpolate(enter, [0, 1], [24, 0])}px)`,
        }}
      >
        <Glass radius={40} padding="16px 36px" tone="dark" shine={2}>
          <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", columnGap: 18, rowGap: 2 }}>
            {page.words.map((w, i) => {
              const active = frame >= w.s && frame < w.e;
              const wp = spring({ frame: frame - w.s, fps, config: theme.spring.snappy });
              return (
                <span
                  key={i}
                  style={{
                    display: "inline-block",
                    fontSize: 64,
                    fontWeight: 800,
                    lineHeight: theme.type.lineHeight,
                    color: active ? theme.colors.accent : theme.colors.text,
                    transform: `scale(${active ? 1 + 0.06 * Math.min(1, wp) : 1})`,
                    textShadow: `0 4px 18px ${theme.colors.shadow}`,
                  }}
                >
                  {w.text}
                </span>
              );
            })}
          </div>
        </Glass>
      </div>
    </AbsoluteFill>
  );
};
