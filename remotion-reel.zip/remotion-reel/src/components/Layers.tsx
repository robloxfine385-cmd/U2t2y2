import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { clamp } from "./Motion";

/** Layer 1 — vivid blurred backdrop (solid-color blobs + linear gradient base) */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const a = Math.sin(frame / 60) * 70;
  const b = Math.cos(frame / 75) * 60;
  const c = Math.sin(frame / 90 + 1) * 50;
  const blob = (
    size: number,
    color: string,
    opacity: number,
    blur: number,
    pos: React.CSSProperties,
  ): React.CSSProperties => ({
    position: "absolute",
    width: size,
    height: size,
    borderRadius: "50%",
    background: color,
    opacity,
    filter: `blur(${blur}px)`,
    ...pos,
  });
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 55%, ${theme.colors.bg} 100%)`,
      }}
    >
      <div style={blob(900, theme.colors.blue, 0.55, 120, { top: -260 + a, left: -300 + b })} />
      <div style={blob(760, theme.colors.purple, 0.5, 120, { top: 60 - c, right: -280 - a })} />
      <div style={blob(820, theme.colors.pink, 0.34, 130, { top: 760 + b, left: -380 + c })} />
      <div style={blob(860, theme.colors.teal, 0.36, 130, { bottom: -300 - c, right: -320 + a })} />
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade (solid soft-light tint) */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.1 }} />
  </AbsoluteFill>
);

/** Layer 5a — slow glass sheen drifting across the whole frame (linear gradient only) */
export const Sheen: React.FC = () => {
  const frame = useCurrentFrame();
  const x = interpolate(frame % 300, [0, 299], [-1500, 1500], { easing: theme.ease.inOut, ...clamp });
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          top: -240,
          left: 0,
          width: 520,
          height: 2400,
          transform: `translateX(${x}px) rotate(18deg)`,
          background: `linear-gradient(90deg, transparent, ${theme.colors.glassLo}, transparent)`,
        }}
      />
    </AbsoluteFill>
  );
};

/** Layer 5b — vignette from linear gradients only */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: [
        "linear-gradient(180deg, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0) 16%, rgba(0,0,0,0) 84%, rgba(0,0,0,0.34) 100%)",
        "linear-gradient(90deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0) 14%, rgba(0,0,0,0) 86%, rgba(0,0,0,0.2) 100%)",
      ].join(", "),
    }}
  />
);
