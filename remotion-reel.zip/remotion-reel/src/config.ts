import timing from "./timing.json";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// timing.json is rewritten by scripts/sync-audio.mjs from public/voiceover.mp3 (runs automatically before studio/render).
export const AUDIO_FILE: string | null = timing.audioFile;
export const HAS_AUDIO: boolean = timing.hasAudio && timing.audioFile !== null;
export const DURATION_SECONDS: number = timing.duration + 0.6;
export const DURATION_FRAMES = Math.floor(DURATION_SECONDS * FPS);

// Uses the 4 small WAVs shipped in public/sfx. Set false for a voiceover-only render.
export const SFX_ENABLED = true;

// Default list-item timing (frames, local to the beat) when a list beat has no `itemAt`
export const LIST_ITEM_DELAY = 10;
export const LIST_ITEM_STEP = 6;

// 9:16 safe area: keep everything between y≈170 and y≈1560 (platform UI covers top/bottom).
export const L = {
  zone: { y: 330, h: 900 }, // where beat graphics live
  captionY: 1400, // vertical center of the caption block
  fs: 1.25, // font scale for beat graphics
} as const;
