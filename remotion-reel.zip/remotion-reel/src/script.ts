// ─────────────────────────────────────────────────────────────────────────────
// SCRIPT + BEATS (the only file you edit)
//
// SCRIPT    : your exact voiceover, one sentence per entry. Sentence timing is aligned to the
//             pauses detected in public/voiceover.mp3. Captions are cut into short parts automatically.
// BEAT_DEFS : motion graphics anchored to sentences (not seconds), so they stay in sync with the audio.
//             from/to = sentence index (0-based, `to` inclusive). a/b = start/end as a fraction (0–1)
//             of that span. Text below is taken word-for-word from the script.
// ─────────────────────────────────────────────────────────────────────────────

export const SCRIPT: string[] = [
  "গাইস আপনারা অবশ্যই কনফিউজ হয়ে যাবেন যে একটা খতরনাক ১ লাখ টাকার কম্পিউটার কেনা উচিত নাকি ১ লাখ টাকার ফোন কেনা উচিত।",
  "তো আমি বলব যে ১ লাখ টাকার ফোন না কিনে ১ লাখ টাকার কম্পিউটার কিনুন।",
  "কেননা যদি আপনারা গেমিং করতে চান, তাহলে আপনারা অবশ্যই ১ লাখ টাকার কম্পিউটার বা ল্যাপটপ কিনতে পারেন।",
  "ওর মধ্যে সব থেকে ভালো ভালো গেম চলবে যেমন জিটিএ ৫, রেড ডেড রিডেম্পশন।",
  "এমনকি জিটিএ সিক্স-ও ওটার মধ্যে চলবে।",
  "আর আরো হেভি হেভি গেম চলবে যেরকম এখন নতুন এসছে কল অফ ডিউটি মডার্ন ওয়ারফেয়ার, এটাও চলবে।",
  "কিন্তু এই জিনিসটা আপনারা ফোনে পাবেন না।",
  "যদি আপনারা প্রিমিয়ামনেস চান তাও আপনারা ফোনের দিকে যেতে পারেন।",
  "যদি আপনাদের পকেট ফ্রেন্ডলি লাগে তো আপনারা ল্যাপটপ বা ফোন কিনতে পারেন, এটা আপনাদের ট্রাভেলের জন্য সাহায্য করবে।",
  "আর আমি একটা জিনিস বলব যে যদি আপনারা বেশি ঘরে থাকেন তাহলে একটা পিসি নিন।",
  "আর যদি বাইরে বেশি ঘোরেন তো আপনারা একটা ফোন বা ল্যাপটপ কিনতে পারেন।",
  "কিন্তু ফোন আমি একদম রেকমেন্ড করবো না, কেননা গেমিং এর জন্য সব থেকে ভালো এফপিএস দিতে পারে কম্পিউটার বা ল্যাপটপ।",
];

export type Spec =
  | { type: "hook"; title: string; sub?: string; highlight?: number }
  | { type: "vs"; top: string; bottom: string; win: "top" | "bottom"; tag?: string }
  | { type: "keyword"; word: string; label?: string }
  | {
      type: "stat";
      value: number;
      label: string;
      prefix?: string;
      suffix?: string;
      decimals?: number;
      fill?: number;
      numerals?: "bn" | "en";
    }
  | { type: "list"; title?: string; items: string[]; itemAt?: number[] }
  | { type: "cta"; title: string; button: string };

type Anchor = { from: number; to?: number; a?: number; b?: number };
export type BeatDef = Spec & Anchor;
export type Beat = Spec & { start: number; end: number };

export const BEAT_DEFS: BeatDef[] = [
  { from: 0, type: "hook", title: "১ লাখ টাকার", sub: "কম্পিউটার নাকি ফোন", highlight: 1 },
  { from: 1, type: "vs", top: "কম্পিউটার", bottom: "ফোন", tag: "নাকি", win: "top" },
  { from: 2, a: 0.08, type: "keyword", word: "গেমিং", label: "কম্পিউটার বা ল্যাপটপ" },
  { from: 3, a: 0.4, type: "list", title: "গেম চলবে", items: ["জিটিএ ৫", "রেড ডেড রিডেম্পশন"], itemAt: [0.16, 0.6] },
  { from: 4, type: "keyword", word: "জিটিএ সিক্স", label: "এমনকি" },
  { from: 5, a: 0.3, type: "keyword", word: "কল অফ ডিউটি", label: "মডার্ন ওয়ারফেয়ার" },
  { from: 6, type: "keyword", word: "ফোনে পাবেন না", label: "কিন্তু" },
  { from: 7, type: "keyword", word: "প্রিমিয়ামনেস", label: "ফোনের দিকে" },
  { from: 8, a: 0, b: 0.58, type: "keyword", word: "পকেট ফ্রেন্ডলি", label: "ল্যাপটপ বা ফোন" },
  { from: 8, a: 0.64, type: "keyword", word: "ট্রাভেল", label: "ল্যাপটপ বা ফোন" },
  { from: 9, type: "keyword", word: "পিসি", label: "বেশি ঘরে থাকেন" },
  { from: 10, type: "keyword", word: "ফোন বা ল্যাপটপ", label: "বাইরে বেশি ঘোরেন" },
  { from: 11, a: 0, b: 0.34, type: "keyword", word: "ফোন", label: "একদম রেকমেন্ড করবো না" },
  { from: 11, a: 0.5, type: "keyword", word: "এফপিএস", label: "গেমিং এর জন্য" },
];
