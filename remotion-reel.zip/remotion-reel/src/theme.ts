// Single source of truth. Apple-style glassmorphism: vivid blurred backdrop + frosted translucent panels.
// Linear gradients and solid colors only — no noise textures.
import { Easing } from "remotion";
import { FONT_STACK } from "./fonts";

export const theme = {
  colors: {
    bg: "#070A14",
    bgAlt: "#0F1530",
    // backdrop blobs (Apple system colors)
    blue: "#0A84FF",
    purple: "#BF5AF2",
    pink: "#FF375F",
    teal: "#30D5C8",
    // hero + accent
    primary: "#64D2FF", // THE hero color — max one element per frame
    primaryHi: "#8FE3FF",
    accent: "#FFD60A", // caption active word
    text: "#FFFFFF",
    textDim: "rgba(235, 235, 245, 0.72)",
    glow: "rgba(100, 210, 255, 0.5)",
    // glass
    glassHi: "rgba(255, 255, 255, 0.24)",
    glassLo: "rgba(255, 255, 255, 0.08)",
    glassDarkHi: "rgba(28, 32, 52, 0.58)",
    glassDarkLo: "rgba(10, 12, 24, 0.5)",
    glassBorder: "rgba(255, 255, 255, 0.3)",
    glassEdge: "rgba(255, 255, 255, 0.5)",
    glassSheen: "rgba(255, 255, 255, 0.3)",
    track: "rgba(255, 255, 255, 0.2)",
    shadow: "rgba(0, 0, 0, 0.4)",
  },
  fonts: { stack: FONT_STACK },
  glassBlur: "blur(30px) saturate(180%)",
  // Bengali: no letter-spacing tweaks (breaks conjuncts), tall line-height for matras.
  type: { lineHeight: 1.3, letterSpacing: 0 },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
