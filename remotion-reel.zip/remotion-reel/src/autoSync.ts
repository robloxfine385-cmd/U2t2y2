export type Pause = { t: number; d: number }; // midpoint + length (seconds) of a detected pause
export type Seg = { text: string; start: number; end: number };

const weight = (t: string) => Math.max(1, [...t.replace(/\s+/g, "")].length);

/**
 * Places the boundaries between sentences. Candidates = detected pauses (+ proportional guesses as a
 * fallback). Dynamic programming picks the set of pauses that makes every sentence's duration
 * proportional to its text length, preferring longer pauses.
 */
export const alignSentences = (
  sentences: string[],
  opts: { start: number; end: number; pauses: Pause[]; minLen?: number },
): Seg[] => {
  const { start, end, pauses, minLen = 1.0 } = opts;
  const n = sentences.length;
  if (n <= 1) return sentences.map((text) => ({ text, start, end }));

  const w = sentences.map(weight);
  const W = w.reduce((a, b) => a + b, 0);
  const exp = w.map((x) => (x / W) * (end - start));

  type Cand = { t: number; bonus: number };
  const cands: Cand[] = [];
  for (const p of pauses) {
    if (p.t > start + minLen && p.t < end - minLen) cands.push({ t: p.t, bonus: 0.6 * Math.min(p.d, 1) });
  }
  let acc = 0;
  for (let i = 0; i < n - 1; i++) {
    acc += w[i];
    cands.push({ t: start + (end - start) * (acc / W), bonus: -0.4 }); // virtual (penalised)
  }
  cands.sort((a, b) => a.t - b.t);

  const M = cands.length;
  const INF = 1e12;
  const dp: number[][] = Array.from({ length: n }, () => new Array<number>(M).fill(INF));
  const prev: number[][] = Array.from({ length: n }, () => new Array<number>(M).fill(-1));
  const seg = (len: number, i: number) => ((len - exp[i]) ** 2) / exp[i];

  for (let m = 0; m < M; m++) {
    const len = cands[m].t - start;
    if (len >= minLen) dp[1][m] = seg(len, 0) - cands[m].bonus;
  }
  for (let i = 2; i < n; i++) {
    for (let m = 0; m < M; m++) {
      for (let k = 0; k < m; k++) {
        if (dp[i - 1][k] >= INF) continue;
        const len = cands[m].t - cands[k].t;
        if (len < minLen) continue;
        const c = dp[i - 1][k] + seg(len, i - 1) - cands[m].bonus;
        if (c < dp[i][m]) {
          dp[i][m] = c;
          prev[i][m] = k;
        }
      }
    }
  }
  let best = INF;
  let bm = -1;
  for (let m = 0; m < M; m++) {
    if (dp[n - 1][m] >= INF) continue;
    const len = end - cands[m].t;
    if (len < minLen) continue;
    const c = dp[n - 1][m] + seg(len, n - 1);
    if (c < best) {
      best = c;
      bm = m;
    }
  }

  const bounds: number[] = [start];
  if (bm === -1) {
    let a2 = 0;
    for (let i = 0; i < n - 1; i++) {
      a2 += w[i];
      bounds.push(start + (end - start) * (a2 / W));
    }
  } else {
    const idx: number[] = new Array<number>(n).fill(-1);
    let m = bm;
    for (let i = n - 1; i >= 1; i--) {
      idx[i] = m;
      m = prev[i][m];
    }
    for (let i = 1; i < n; i++) bounds.push(cands[idx[i]].t);
  }
  bounds.push(end);

  return sentences.map((text, i) => ({ text, start: bounds[i], end: bounds[i + 1] }));
};

/** Cuts a sentence into short caption parts: at commas/danda first, then into balanced chunks of ≤ maxWords. */
export const splitPhrases = (sentence: string, maxWords = 4): string[] => {
  const clauses = sentence
    .split(/[,،;।]/)
    .map((s) => s.trim())
    .filter(Boolean);
  const out: string[] = [];
  for (const clause of clauses) {
    const words = clause.split(/\s+/).filter(Boolean);
    const k = Math.ceil(words.length / maxWords);
    const base = Math.floor(words.length / k);
    const extra = words.length % k;
    let i = 0;
    for (let j = 0; j < k; j++) {
      const size = base + (j < extra ? 1 : 0);
      out.push(words.slice(i, i + size).join(" "));
      i += size;
    }
  }
  return out;
};

/** Times caption parts inside one sentence: proportional to text length, nudged onto nearby pauses. */
export const timePhrases = (
  phrases: string[],
  start: number,
  end: number,
  pauses: Pause[],
  snap = 0.4,
): Seg[] => {
  const w = phrases.map(weight);
  const W = w.reduce((a, b) => a + b, 0);
  const bounds: number[] = [start];
  let acc = 0;
  for (let i = 0; i < phrases.length - 1; i++) {
    acc += w[i];
    const ideal = start + (end - start) * (acc / W);
    let t = ideal;
    let bd = snap;
    for (const p of pauses) {
      const d = Math.abs(p.t - ideal);
      if (d < bd) {
        t = p.t;
        bd = d;
      }
    }
    const lo = bounds[bounds.length - 1] + 0.35;
    const hi = end - 0.35;
    bounds.push(lo > hi ? ideal : Math.min(hi, Math.max(lo, t)));
  }
  bounds.push(end);
  return phrases.map((text, i) => ({ text, start: bounds[i], end: bounds[i + 1] }));
};
