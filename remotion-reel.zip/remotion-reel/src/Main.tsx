import React from "react";
import { AbsoluteFill, Html5Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { BeatView } from "./Beats";
import { Captions } from "./components/Captions";
import { BgMesh, Grade, Sheen, Vignette } from "./components/Layers";
import { sec } from "./components/Motion";
import { Sfx } from "./components/Sfx";
import { AUDIO_FILE, HAS_AUDIO } from "./config";
import { BEATS } from "./timing";
import { theme } from "./theme";

export const Main: React.FC = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.bg,
        fontFamily: theme.fonts.stack,
        letterSpacing: theme.type.letterSpacing,
      }}
    >
      <BgMesh />
      {BEATS.map((b, i) => {
        const from = sec(b.start, fps);
        const dur = Math.max(12, sec(b.end, fps) - from);
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <BeatView beat={b} />
          </Sequence>
        );
      })}
      <Captions />
      <Grade />
      <Sheen />
      <Vignette />
      {HAS_AUDIO && AUDIO_FILE ? <Html5Audio src={staticFile(AUDIO_FILE)} /> : null}
      <Sfx />
    </AbsoluteFill>
  );
};
