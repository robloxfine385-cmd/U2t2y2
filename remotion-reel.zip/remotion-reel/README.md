# remotion-reel — Apple glassmorphism, 1080×1920

1. `npm install`
2. Put your voiceover at `public/voiceover.mp3`
3. `npm run studio` (preview) or `npm run render` → `out/video.mp4`

The audio is analysed automatically before studio/render (`scripts/sync-audio.mjs` → `src/timing.json`):
length, speech start/end and pauses. Sentences, captions and graphics are aligned to it.
Without the MP3 the project still renders (silent, estimated timing).

- Script + graphics: `src/script.ts`
- Background: CSS linear gradient + blurred solid-color blobs (`src/components/Layers.tsx`)
- SFX: 4 WAVs in `public/sfx` (`SFX_ENABLED` in `src/config.ts`)
